<div class="wrap">
    <div id="frontend-admin-menu-backend">
        <?php _e( '<h2>Frontend admin menu - Options</h2>', 'frontend-admin-menu' ); ?>
        <div id="gs-middle">
            <?php require_once( FRONTEND_ADMIN_MENU_DIR . "admin/includes/gs-middle-options-page.php" ); ?>
        </div>
    </div>
</div>


